# This is my better script
# Done using different approaches
